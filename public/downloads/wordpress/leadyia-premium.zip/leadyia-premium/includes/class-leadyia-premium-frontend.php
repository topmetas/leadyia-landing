<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_Frontend {
    private static $instance = null;
    private $settings = array();

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        // Same simple loader as Vite, but executed after <body> exists.
        add_action('wp_footer', array($this, 'render_loader'), 99);
        add_filter('wp_resource_hints', array($this, 'resource_hints'), 10, 2);
        add_shortcode('leadyia_widget', array($this, 'shortcode_status'));
        add_shortcode('leadyia_button', array($this, 'shortcode_button'));
        add_action('init', array($this, 'register_block'));
    }

    private function is_enabled() {
        $this->settings = LeadyIA_Premium_Settings::all();

        if (empty($this->settings['enabled']) || empty($this->settings['tenant_id'])) {
            return false;
        }

        if (!empty($this->settings['hide_mobile']) && wp_is_mobile()) {
            return false;
        }

        return true;
    }

    private function build_context() {
        $context = array(
            'page' => array(
                'url' => esc_url_raw(home_url(add_query_arg(array(), $GLOBALS['wp']->request ?? ''))),
                'title' => wp_get_document_title(),
                'postId' => get_queried_object_id(),
                'postType' => get_post_type(),
            ),
            'wordpress' => array(
                'siteName' => get_bloginfo('name'),
                'locale' => determine_locale(),
                'isLoggedIn' => is_user_logged_in(),
            ),
            'woocommerce' => LeadyIA_Premium_WooCommerce::context(),
        );

        if (!empty($this->settings['show_logged_user_context']) && is_user_logged_in()) {
            $user = wp_get_current_user();
            $context['wordpress']['user'] = array(
                'id' => (int) $user->ID,
                'name' => $user->display_name,
                'roles' => array_values($user->roles),
            );
        }

        return $context;
    }

    public function render_loader() {
        if (!$this->is_enabled()) return;

        $tenant_id = sanitize_text_field($this->settings['tenant_id']);
        $widget_url = esc_url_raw($this->settings['widget_url'] ?? 'https://widget.leadyia.com/v1/widget.js');
        $context = wp_json_encode($this->build_context());

        // Keep WordPress/WooCommerce context available to the runtime.
        echo '<script id="leadyia-wordpress-context" data-cfasync="false" data-nowprocket="1">';
        echo 'window.leadyiaContext=' . $context . ';';
        echo '</script>';

        // Intentionally mirrors the known-good Vite loader.
        echo '<script id="leadyia-wordpress-loader"';
        echo ' data-key="' . esc_attr($tenant_id) . '"';
        echo ' data-cfasync="false" data-nowprocket="1" data-no-optimize="1">';
        ?>
(function () {
  const script = document.currentScript;

  const publicKey = script.getAttribute("data-key");

  if (!publicKey) {
    console.error("LeadyIA: data-key obrigatório.");
    return;
  }

  const mountWidget = function () {
    const widgetScript = document.createElement("script");
    widgetScript.src = <?php echo wp_json_encode($widget_url); ?>;
    widgetScript.async = true;
    widgetScript.setAttribute("data-tenant", publicKey);
    widgetScript.setAttribute("data-playbook", <?php echo wp_json_encode((string) ($this->settings['playbook'] ?? 'leadyia')); ?>);
    widgetScript.setAttribute("data-source", "wordpress");
    widgetScript.setAttribute("data-theme", <?php echo wp_json_encode((string) ($this->settings['theme'] ?? 'dark')); ?>);
    widgetScript.setAttribute("data-position", <?php echo wp_json_encode((string) ($this->settings['position'] ?? 'right')); ?>);
    widgetScript.setAttribute("data-primary-color", <?php echo wp_json_encode((string) ($this->settings['primary_color'] ?? '#6366f1')); ?>);
    widgetScript.setAttribute("data-api-base", <?php echo wp_json_encode((string) ($this->settings['api_url'] ?? 'https://api.leadyia.com')); ?>);
    if (<?php echo !empty($this->settings['debug']) ? 'true' : 'false'; ?>) {
      widgetScript.setAttribute("data-debug", "true");
    }
    document.body.appendChild(widgetScript);
  };

  if (document.body) {
    mountWidget();
  } else {
    window.addEventListener("DOMContentLoaded", mountWidget, { once: true });
  }
})();
        <?php
        echo '</script>';
    }

    public function resource_hints($urls, $relation_type) {
        if (!$this->is_enabled()) return $urls;

        if ('preconnect' === $relation_type || 'dns-prefetch' === $relation_type) {
            $widget_host = wp_parse_url((string) ($this->settings['widget_url'] ?? ''), PHP_URL_HOST);
            $api_host = wp_parse_url((string) ($this->settings['api_url'] ?? ''), PHP_URL_HOST);

            if ($widget_host) {
                $urls[] = 'https://' . $widget_host;
            }

            if ($api_host) {
                $urls[] = 'https://' . $api_host;
            }
        }

        return array_values(array_unique($urls));
    }

    public function shortcode_status() {
        if (!current_user_can('manage_options')) return '';
        return '<span class="leadyia-status">' .
            (LeadyIA_Premium_Settings::get('enabled')
                ? esc_html__('LeadyIA ativa', 'leadyia-premium')
                : esc_html__('LeadyIA desativada', 'leadyia-premium')) .
            '</span>';
    }

    public function shortcode_button($atts) {
        $atts = shortcode_atts(
            array(
                'label' => __('Falar com a IA', 'leadyia-premium'),
                'class' => '',
            ),
            $atts,
            'leadyia_button'
        );

        return sprintf(
            '<button type="button" class="leadyia-open-button %s" data-leadyia-open>%s</button>',
            esc_attr($atts['class']),
            esc_html($atts['label'])
        );
    }

    public function register_block() {
        wp_register_script(
            'leadyia-premium-block',
            LEADYIA_PREMIUM_URL . 'assets/block.js',
            array('wp-blocks', 'wp-element', 'wp-components', 'wp-i18n', 'wp-block-editor'),
            LEADYIA_PREMIUM_VERSION,
            true
        );

        register_block_type('leadyia/chat-button', array(
            'editor_script' => 'leadyia-premium-block',
            'render_callback' => array($this, 'render_block'),
            'attributes' => array(
                'label' => array(
                    'type' => 'string',
                    'default' => __('Falar com a IA', 'leadyia-premium'),
                ),
            ),
        ));
    }

    public function render_block($attributes) {
        return $this->shortcode_button(array(
            'label' => $attributes['label'] ?? __('Falar com a IA', 'leadyia-premium'),
        ));
    }
}
