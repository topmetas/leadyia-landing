<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_API_Client {
    public static function request($path, $body = array(), $method = 'POST', $token = '') {
        $base = LeadyIA_Premium_Settings::get('api_url', 'https://api.leadyia.com');
        $url = untrailingslashit($base) . '/' . ltrim($path, '/');
        $headers = array('Content-Type' => 'application/json');
        if ($token) $headers['Authorization'] = 'Bearer ' . $token;

        $args = array(
            'method' => strtoupper($method),
            'headers' => $headers,
            'timeout' => 20,
            'redirection' => 3,
            'sslverify' => true,
        );

        if ('GET' === $args['method']) {
            if ($body) $url = add_query_arg($body, $url);
        } else {
            $args['body'] = wp_json_encode($body);
        }

        $response = wp_safe_remote_request($url, $args);
        if (is_wp_error($response)) {
            return array('success' => false, 'status' => 0, 'message' => $response->get_error_message());
        }

        $status = (int) wp_remote_retrieve_response_code($response);
        $raw = wp_remote_retrieve_body($response);
        $data = json_decode($raw, true);
        if (!is_array($data)) $data = array('raw' => $raw);

        return array(
            'success' => $status >= 200 && $status < 300,
            'status' => $status,
            'message' => $data['message'] ?? ($status >= 400 ? __('A API recusou a solicitação.', 'leadyia-premium') : ''),
            'data' => $data,
        );
    }

    public static function test_tenant($tenant_id) {
        $tenant_id = sanitize_text_field($tenant_id);
        if (!$tenant_id) return array('success' => false, 'message' => __('Informe o Tenant ID.', 'leadyia-premium'));

        return self::request('/api/widget/bootstrap', array(
            'tenantId' => $tenant_id,
            'channel' => 'wordpress',
            'origin' => home_url('/'),
            'locale' => LeadyIA_Premium_Settings::get('locale', 'pt-BR'),
        ));
    }
}
