<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_Admin {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', array($this, 'menu'));
        add_action('admin_enqueue_scripts', array($this, 'assets'));
        add_action('wp_ajax_leadyia_premium_test_connection', array($this, 'test_connection'));
    }

    public function menu() {
        add_menu_page(
            __('LeadyIA Premium', 'leadyia-premium'),
            __('LeadyIA', 'leadyia-premium'),
            'manage_options',
            'leadyia-premium',
            array($this, 'page'),
            'dashicons-format-chat',
            58
        );
    }

    public function assets($hook) {
        if ('toplevel_page_leadyia-premium' !== $hook) return;
        wp_enqueue_style('leadyia-premium-admin', LEADYIA_PREMIUM_URL . 'assets/admin.css', array(), LEADYIA_PREMIUM_VERSION);
        wp_enqueue_script('leadyia-premium-admin', LEADYIA_PREMIUM_URL . 'assets/admin.js', array(), LEADYIA_PREMIUM_VERSION, true);
        wp_localize_script('leadyia-premium-admin', 'LeadyIAAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('leadyia_premium_admin'),
            'testing' => __('Testando...', 'leadyia-premium'),
        ));
    }

    public function test_connection() {
        check_ajax_referer('leadyia_premium_admin', 'nonce');
        if (!current_user_can('manage_options')) wp_send_json_error(array('message' => __('Sem permissão.', 'leadyia-premium')), 403);
        $tenant = sanitize_text_field(wp_unslash($_POST['tenantId'] ?? ''));
        $result = LeadyIA_Premium_API_Client::test_tenant($tenant);

        if ($result['success']) {
            $settings = LeadyIA_Premium_Settings::all();
            $settings['tenant_id'] = $tenant;
            $settings['enabled'] = empty($_POST['enabled']) ? 0 : 1;

            if (!empty($_POST['playbook'])) {
                $settings['playbook'] = sanitize_key(wp_unslash($_POST['playbook']));
            }

            if (!empty($_POST['widgetUrl'])) {
                $settings['widget_url'] = esc_url_raw(wp_unslash($_POST['widgetUrl']));
            }

            update_option(LEADYIA_PREMIUM_OPTION, $settings, false);
            update_option('leadyia_premium_loader_revision', time(), false);

            if (class_exists('LeadyIA_Premium_Cache')) {
                LeadyIA_Premium_Cache::instance()->purge_all();
            }

            wp_send_json_success(array(
                'message' => __('Conexão confirmada e configuração salva. O widget foi ativado no site público.', 'leadyia-premium'),
                'status' => $result['status'],
                'saved' => true,
                'enabled' => (bool) $settings['enabled'],
            ));
        }

        wp_send_json_error(array(
            'message' => $result['message'] ?: __('Não foi possível validar o tenant.', 'leadyia-premium'),
            'status' => $result['status'],
        ));
    }

    public function page() {
        if (!current_user_can('manage_options')) return;
        $s = LeadyIA_Premium_Settings::all();
        $diagnostics = LeadyIA_Premium_Diagnostics::snapshot();
        ?>
        <div class="leadyia-admin-wrap">
            <header class="leadyia-admin-hero">
                <div>
                    <span class="leadyia-admin-eyebrow">LEADYIA PREMIUM</span>
                    <h1><?php esc_html_e('Sua IA comercial dentro do WordPress', 'leadyia-premium'); ?></h1>
                    <p><?php esc_html_e('Conecte o tenant, personalize o widget e leve contexto seguro do site e do WooCommerce para cada conversa.', 'leadyia-premium'); ?></p>
                </div>
                <div class="leadyia-status-pill <?php echo $s['enabled'] && $s['tenant_id'] ? 'is-on' : 'is-off'; ?>">
                    <?php echo $s['enabled'] && $s['tenant_id'] ? esc_html__('Ativa', 'leadyia-premium') : esc_html__('Configuração pendente', 'leadyia-premium'); ?>
                </div>
            </header>

            <form method="post" action="options.php" class="leadyia-admin-form">
                <?php settings_fields('leadyia_premium_group'); ?>

                <nav class="leadyia-tabs" aria-label="<?php esc_attr_e('Configurações do plugin', 'leadyia-premium'); ?>">
                    <button type="button" class="is-active" data-tab="connection"><?php esc_html_e('Conexão', 'leadyia-premium'); ?></button>
                    <button type="button" data-tab="appearance"><?php esc_html_e('Aparência', 'leadyia-premium'); ?></button>
                    <button type="button" data-tab="behavior"><?php esc_html_e('Comportamento', 'leadyia-premium'); ?></button>
                    <button type="button" data-tab="commerce"><?php esc_html_e('WooCommerce', 'leadyia-premium'); ?></button>
                    <button type="button" data-tab="diagnostics"><?php esc_html_e('Diagnóstico', 'leadyia-premium'); ?></button>
                </nav>

                <section class="leadyia-panel is-active" data-panel="connection">
                    <h2><?php esc_html_e('Conecte seu tenant', 'leadyia-premium'); ?></h2>
                    <p><?php esc_html_e('Use o Tenant ID exibido no Dashboard LeadyIA. O plugin não armazena sua senha.', 'leadyia-premium'); ?></p>
                    <?php $this->field_text('tenant_id', __('Tenant ID', 'leadyia-premium'), $s['tenant_id'], '69f168938e078fba344fe491'); ?>
                    <?php $this->field_select('playbook', __('Playbook', 'leadyia-premium'), $s['playbook'], array('leadyia'=>'LeadyIA','clinic'=>'Clínica','aesthetics'=>'Estética','real_estate'=>'Imobiliária','legal'=>'Advocacia','education'=>'Educação','ecommerce'=>'E-commerce','saas'=>'SaaS')); ?>
                    <?php $this->field_checkbox('enabled', __('Ativar o widget no site', 'leadyia-premium'), $s['enabled']); ?>
                    <div class="leadyia-inline-actions">
                        <button type="button" class="button button-secondary" id="leadyia-test-connection"><?php esc_html_e('Testar conexão', 'leadyia-premium'); ?></button>
                        <a class="button" href="https://dashboard.leadyia.com" target="_blank" rel="noopener noreferrer"><?php esc_html_e('Abrir Dashboard', 'leadyia-premium'); ?></a>
                        <span id="leadyia-test-result" role="status"></span>
                    </div>
                    <details class="leadyia-advanced"><summary><?php esc_html_e('Configuração avançada de endpoints', 'leadyia-premium'); ?></summary>
                        <?php $this->field_text('api_url', __('API URL', 'leadyia-premium'), $s['api_url']); ?>
                        <?php $this->field_text('widget_url', __('Widget URL', 'leadyia-premium'), $s['widget_url']); ?>
                    </details>
                </section>

                <section class="leadyia-panel" data-panel="appearance">
                    <h2><?php esc_html_e('Aparência e identidade', 'leadyia-premium'); ?></h2>
                    <?php $this->field_text('bot_name', __('Nome do assistente', 'leadyia-premium'), $s['bot_name']); ?>
                    <?php $this->field_select('theme', __('Tema', 'leadyia-premium'), $s['theme'], array('dark'=>__('Escuro','leadyia-premium'),'light'=>__('Claro','leadyia-premium'),'auto'=>__('Automático','leadyia-premium'))); ?>
                    <?php $this->field_select('position', __('Posição', 'leadyia-premium'), $s['position'], array('right'=>__('Direita','leadyia-premium'),'left'=>__('Esquerda','leadyia-premium'))); ?>
                    <?php $this->field_select('locale', __('Idioma', 'leadyia-premium'), $s['locale'], array('pt-BR'=>'Português (Brasil)','en-US'=>'English','es-ES'=>'Español')); ?>
                    <label class="leadyia-field"><span><?php esc_html_e('Cor principal', 'leadyia-premium'); ?></span><input type="color" name="<?php echo esc_attr(LEADYIA_PREMIUM_OPTION); ?>[primary_color]" value="<?php echo esc_attr($s['primary_color']); ?>"></label>
                </section>

                <section class="leadyia-panel" data-panel="behavior">
                    <h2><?php esc_html_e('Comportamento do widget', 'leadyia-premium'); ?></h2>
                    <?php $this->field_checkbox('auto_open', __('Abrir automaticamente', 'leadyia-premium'), $s['auto_open']); ?>
                    <label class="leadyia-field"><span><?php esc_html_e('Atraso para abrir (segundos)', 'leadyia-premium'); ?></span><input type="number" min="0" max="60" name="<?php echo esc_attr(LEADYIA_PREMIUM_OPTION); ?>[auto_open_delay]" value="<?php echo esc_attr($s['auto_open_delay']); ?>"></label>
                    <?php $this->field_checkbox('hide_mobile', __('Ocultar em celulares', 'leadyia-premium'), $s['hide_mobile']); ?>
                    <?php $this->field_checkbox('show_logged_user_context', __('Compartilhar nome e perfil do usuário conectado', 'leadyia-premium'), $s['show_logged_user_context']); ?>
                    <?php $this->field_checkbox('debug', __('Ativar logs no console do navegador', 'leadyia-premium'), $s['debug']); ?>
                    <div class="leadyia-code-card"><strong><?php esc_html_e('Atalhos', 'leadyia-premium'); ?></strong><code>[leadyia_button label="Falar com a IA"]</code><code>[leadyia_widget]</code><p><?php esc_html_e('Também existe o bloco Gutenberg “Botão LeadyIA”.', 'leadyia-premium'); ?></p></div>
                </section>

                <section class="leadyia-panel" data-panel="commerce">
                    <h2><?php esc_html_e('WooCommerce', 'leadyia-premium'); ?></h2>
                    <p><?php esc_html_e('O contexto inclui somente informações públicas do produto e totais agregados do carrinho. Dados de pedidos e pagamento não são expostos.', 'leadyia-premium'); ?></p>
                    <?php $this->field_checkbox('woocommerce_context', __('Enviar contexto seguro do WooCommerce', 'leadyia-premium'), $s['woocommerce_context'], !LeadyIA_Premium_WooCommerce::available()); ?>
                    <div class="leadyia-health <?php echo LeadyIA_Premium_WooCommerce::available() ? 'is-good' : 'is-muted'; ?>"><?php echo LeadyIA_Premium_WooCommerce::available() ? esc_html__('WooCommerce detectado e compatível.', 'leadyia-premium') : esc_html__('WooCommerce não está ativo neste site.', 'leadyia-premium'); ?></div>
                </section>

                <section class="leadyia-panel" data-panel="diagnostics">
                    <h2><?php esc_html_e('Diagnóstico', 'leadyia-premium'); ?></h2>
                    <div class="leadyia-diagnostics">
                    <?php foreach ($diagnostics as $key => $value): ?>
                        <div><span><?php echo esc_html($key); ?></span><strong><?php echo esc_html(is_bool($value) ? ($value ? 'OK' : 'Não') : (string)$value); ?></strong></div>
                    <?php endforeach; ?>
                    </div>
                </section>

                <footer class="leadyia-savebar">
                    <span><?php esc_html_e('As alterações entram em vigor após salvar e limpar o cache do site.', 'leadyia-premium'); ?></span>
                    <?php submit_button(__('Salvar configurações', 'leadyia-premium'), 'primary', 'submit', false); ?>
                </footer>
            </form>
        </div>
        <?php
    }

    private function field_text($key, $label, $value, $placeholder = '') {
        printf('<label class="leadyia-field"><span>%s</span><input type="text" name="%s[%s]" value="%s" placeholder="%s"></label>', esc_html($label), esc_attr(LEADYIA_PREMIUM_OPTION), esc_attr($key), esc_attr($value), esc_attr($placeholder));
    }

    private function field_select($key, $label, $value, $options) {
        echo '<label class="leadyia-field"><span>' . esc_html($label) . '</span><select name="' . esc_attr(LEADYIA_PREMIUM_OPTION) . '[' . esc_attr($key) . ']">';
        foreach ($options as $option_value => $option_label) echo '<option value="' . esc_attr($option_value) . '" ' . selected($value, $option_value, false) . '>' . esc_html($option_label) . '</option>';
        echo '</select></label>';
    }

    private function field_checkbox($key, $label, $checked, $disabled = false) {
        printf('<label class="leadyia-check"><input type="checkbox" name="%s[%s]" value="1" %s %s><span>%s</span></label>', esc_attr(LEADYIA_PREMIUM_OPTION), esc_attr($key), checked($checked, 1, false), $disabled ? 'disabled' : '', esc_html($label));
    }
}
