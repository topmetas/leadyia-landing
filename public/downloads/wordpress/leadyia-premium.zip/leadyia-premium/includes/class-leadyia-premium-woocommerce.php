<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_WooCommerce {
    public static function available() {
        return class_exists('WooCommerce');
    }

    public static function context() {
        if (!self::available() || !LeadyIA_Premium_Settings::get('woocommerce_context', 1)) return null;

        $context = array('active' => true, 'currency' => get_woocommerce_currency());

        if (function_exists('is_product') && is_product()) {
            global $product;
            if ($product && is_a($product, 'WC_Product')) {
                $context['pageType'] = 'product';
                $context['product'] = array(
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'price' => $product->get_price(),
                    'regularPrice' => $product->get_regular_price(),
                    'onSale' => $product->is_on_sale(),
                    'stockStatus' => $product->get_stock_status(),
                    'sku' => $product->get_sku(),
                    'url' => get_permalink($product->get_id()),
                    'categories' => wp_get_post_terms($product->get_id(), 'product_cat', array('fields' => 'names')),
                );
            }
        } elseif (function_exists('is_cart') && is_cart()) {
            $context['pageType'] = 'cart';
        } elseif (function_exists('is_checkout') && is_checkout()) {
            $context['pageType'] = 'checkout';
        } elseif (function_exists('is_shop') && is_shop()) {
            $context['pageType'] = 'shop';
        }

        if (function_exists('WC') && WC()->cart) {
            $context['cart'] = array(
                'itemsCount' => WC()->cart->get_cart_contents_count(),
                'subtotal' => wp_strip_all_tags(WC()->cart->get_cart_subtotal()),
            );
        }

        return $context;
    }
}
