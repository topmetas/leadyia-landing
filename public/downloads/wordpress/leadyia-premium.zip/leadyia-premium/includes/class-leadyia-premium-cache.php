<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_Cache {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('update_option_' . LEADYIA_PREMIUM_OPTION, array($this, 'purge_after_settings_update'), 10, 3);
        add_action('activated_plugin', array($this, 'purge_after_activation'), 10, 2);
    }

    public function purge_after_settings_update($old_value, $value, $option) {
        $this->purge_all();
        update_option('leadyia_premium_loader_revision', time(), false);
    }

    public function purge_after_activation($plugin, $network_wide) {
        if (plugin_basename(LEADYIA_PREMIUM_FILE) !== $plugin) return;
        $this->purge_all();
        update_option('leadyia_premium_loader_revision', time(), false);
    }

    public function purge_all() {
        if (function_exists('wp_cache_flush')) {
            wp_cache_flush();
        }

        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        }

        if (function_exists('w3tc_flush_all')) {
            w3tc_flush_all();
        }

        if (function_exists('wpfc_clear_all_cache')) {
            wpfc_clear_all_cache(true);
        }

        if (class_exists('LiteSpeed\\Purge')) {
            do_action('litespeed_purge_all');
        }

        do_action('leadyia_premium_cache_purged');
    }
}
