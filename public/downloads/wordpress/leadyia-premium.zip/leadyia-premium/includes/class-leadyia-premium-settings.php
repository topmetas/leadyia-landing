<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_Settings {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    public static function defaults() {
        return array(
            'enabled' => 0,
            'tenant_id' => '',
            'api_url' => 'https://api.leadyia.com',
            'widget_url' => 'https://widget.leadyia.com/v1/widget.js',
            'theme' => 'dark',
            'position' => 'right',
            'locale' => 'pt-BR',
            'playbook' => 'leadyia',
            'bot_name' => 'Assistente Virtual',
            'primary_color' => '#6366f1',
            'auto_open' => 0,
            'auto_open_delay' => 8,
            'hide_mobile' => 0,
            'show_logged_user_context' => 0,
            'woocommerce_context' => 1,
            'debug' => 0,
        );
    }

    public static function all() {
        return wp_parse_args(get_option(LEADYIA_PREMIUM_OPTION, array()), self::defaults());
    }

    public static function get($key, $default = null) {
        $settings = self::all();
        return array_key_exists($key, $settings) ? $settings[$key] : $default;
    }

    private function __construct() {
        add_action('admin_init', array($this, 'register'));
    }

    public function register() {
        register_setting(
            'leadyia_premium_group',
            LEADYIA_PREMIUM_OPTION,
            array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize'),
                'default' => self::defaults(),
            )
        );
    }

    public function sanitize($input) {
        $defaults = self::defaults();
        $input = is_array($input) ? $input : array();
        $out = $defaults;

        $out['enabled'] = empty($input['enabled']) ? 0 : 1;
        $out['tenant_id'] = sanitize_text_field($input['tenant_id'] ?? '');
        $out['api_url'] = untrailingslashit(esc_url_raw($input['api_url'] ?? $defaults['api_url']));
        $out['widget_url'] = esc_url_raw($input['widget_url'] ?? $defaults['widget_url']);
        $out['theme'] = in_array(($input['theme'] ?? ''), array('light', 'dark', 'auto'), true) ? $input['theme'] : 'dark';
        $out['position'] = in_array(($input['position'] ?? ''), array('left', 'right'), true) ? $input['position'] : 'right';
        $out['locale'] = in_array(($input['locale'] ?? ''), array('pt-BR', 'en-US', 'es-ES'), true) ? $input['locale'] : 'pt-BR';
        $out['playbook'] = sanitize_key($input['playbook'] ?? 'leadyia');
        $out['bot_name'] = sanitize_text_field($input['bot_name'] ?? $defaults['bot_name']);
        $color = sanitize_hex_color($input['primary_color'] ?? $defaults['primary_color']);
        $out['primary_color'] = $color ?: $defaults['primary_color'];
        $out['auto_open'] = empty($input['auto_open']) ? 0 : 1;
        $out['auto_open_delay'] = min(60, max(0, absint($input['auto_open_delay'] ?? 8)));
        $out['hide_mobile'] = empty($input['hide_mobile']) ? 0 : 1;
        $out['show_logged_user_context'] = empty($input['show_logged_user_context']) ? 0 : 1;
        $out['woocommerce_context'] = empty($input['woocommerce_context']) ? 0 : 1;
        $out['debug'] = empty($input['debug']) ? 0 : 1;

        return $out;
    }
}
