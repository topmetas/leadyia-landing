<?php
if (!defined('ABSPATH')) exit;

final class LeadyIA_Premium_Diagnostics {
    public static function snapshot() {
        global $wp_version;

        $settings = LeadyIA_Premium_Settings::all();

        return array(
            'pluginVersion' => LEADYIA_PREMIUM_VERSION,
            'wordpressVersion' => $wp_version,
            'phpVersion' => PHP_VERSION,
            'siteUrl' => home_url('/'),
            'https' => is_ssl(),
            'restApi' => !empty(get_option('permalink_structure')),
            'wooCommerce' => LeadyIA_Premium_WooCommerce::available(),
            'tenantConfigured' => (bool) $settings['tenant_id'],
            'widgetEnabled' => (bool) $settings['enabled'],
            'widgetUrl' => $settings['widget_url'],
            'loaderStrategy' => 'vite-compatible-single-inline-head-loader',
            'loaderRevision' => (int) get_option('leadyia_premium_loader_revision', 0),
            'wpRocketDetected' => function_exists('rocket_clean_domain'),
            'objectCache' => wp_using_ext_object_cache(),
            'wpRemotePost' => function_exists('wp_remote_post'),
        );
    }
}
