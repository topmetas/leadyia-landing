=== LeadyIA Premium ===
Contributors: osvaldoabjunior
Tags: ai, chatbot, woocommerce, ecommerce, customer-support
Requires at least: 6.2
Tested up to: 7.0
Requires PHP: 7.4
Stable tag: 6.2.5
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect WordPress and WooCommerce to the hosted LeadyIA conversational service with a configurable widget, optional site context, diagnostics, and conversion shortcuts.

== Description ==

LeadyIA Premium connects a WordPress site to an existing LeadyIA tenant.

The plugin can:

* Load the hosted LeadyIA conversational widget on public pages after an administrator enables it and provides a Tenant ID.
* Provide current page and WordPress context to the widget.
* Optionally provide public WooCommerce product information and aggregate cart information.
* Optionally provide the display name, WordPress user ID, and roles of a logged-in user when an administrator explicitly enables that setting.
* Test the configured tenant connection from the WordPress administration area.
* Provide shortcodes and a Gutenberg button block for opening the assistant.

A LeadyIA account and Tenant ID are required to use the hosted conversational service. Service availability, message limits, automation, CRM, omnichannel features, and plan limits are provided by LeadyIA and are separate from this GPL-licensed WordPress plugin.

== Installation ==

1. Upload the plugin ZIP from Plugins > Add New > Upload Plugin, or install it from the WordPress.org directory when available.
2. Activate LeadyIA Premium.
3. Open LeadyIA in the WordPress administration menu.
4. Enter your LeadyIA Tenant ID.
5. Review the optional WordPress and WooCommerce context settings.
6. Enable the widget and use the connection test.

== External services ==

This plugin depends on hosted LeadyIA services when the widget is enabled or when an administrator tests a tenant connection. The plugin does not provide the conversational AI service locally inside WordPress.

=== LeadyIA API ===

Default service endpoint: https://api.leadyia.com

The LeadyIA API is used to validate the configured tenant and to provide the widget's conversational, CRM, lead, lifecycle, automation, and appointment-related functionality when those features are enabled for the tenant.

When an administrator runs the connection test, the plugin sends the configured Tenant ID, the channel identifier (`wordpress`), the site's public origin URL, and the selected locale to the LeadyIA API.

When a visitor uses the hosted widget, the widget may send the visitor's conversation messages, replies, quick-reply/action selections, session/visitor identifiers, page URL/origin, and technical metadata required to maintain the conversation. If the visitor voluntarily provides contact or lead information in the conversation, the service may process that information, including name, email address, telephone/WhatsApp number, and other information typed by the visitor. If appointment functionality is used, the service may also process information submitted for availability, booking, rescheduling, cancellation, waitlist, service/goal, date, period, and time. These data are sent when the visitor uses the corresponding hosted LeadyIA features.

The administrator can change the API endpoint in the plugin's advanced settings. If it is changed, the same connection-test and widget data may be sent to the administrator-selected endpoint instead of the default LeadyIA API.

=== LeadyIA Widget CDN ===

Default service endpoint: https://widget.leadyia.com
Default script: https://widget.leadyia.com/v1/widget.js

When the widget is enabled, the visitor's browser downloads the LeadyIA widget JavaScript from the configured Widget URL. By default, that script is hosted on the LeadyIA Widget CDN.

The widget is initialized with the configured Tenant ID, playbook/source identifier, theme, position, primary color, API base URL, and optional debugging state.

The page also makes the following context available to the widget: current page URL and title, queried post ID and post type, WordPress site name and locale, and whether a user is logged in. If WooCommerce context is enabled, public product fields (product ID, name, current price, regular price, sale status, stock status, SKU, permalink, and category names) and aggregate cart information (item count and formatted subtotal) may also be made available. Order details and payment details are not added by this plugin.

If the administrator explicitly enables logged-in user context, the logged-in user's WordPress user ID, display name, and roles are also made available to the widget.

The administrator can change the Widget URL in the plugin's advanced settings. If it is changed, the visitor's browser will load JavaScript from the administrator-selected URL instead of the default LeadyIA Widget CDN.

LeadyIA provides the default hosted API and widget services. Review the applicable service terms and privacy information before enabling the integration:

* Terms of Service: https://leadyia.com/terms
* Privacy Policy: https://leadyia.com/privacy

== Frequently Asked Questions ==

= Does this plugin work without a LeadyIA account? =

The WordPress plugin can be installed, but the hosted conversational features require a valid LeadyIA tenant.

= Does the plugin send WooCommerce orders or payment data? =

No. The optional WooCommerce context implemented by this plugin is limited to public product fields and aggregate cart information. It does not add order or payment details to the widget context.

= Is logged-in user information shared automatically? =

No. Logged-in user context is disabled by default and must be explicitly enabled by a WordPress administrator.

= Does the plugin load remote code? =

When the administrator enables the widget, the visitor's browser loads the LeadyIA widget JavaScript from the configured Widget URL. The default URL is the hosted LeadyIA Widget CDN documented above. This remote script is required to provide the hosted LeadyIA conversational service.

== Changelog ==

= 6.2.5 =
* Aligned frontend widget attributes with the v1103.216 runtime contract.
* Expanded external-service disclosure for conversations, lead identity, lifecycle, and appointment data.
* Documented administrator-configurable API and Widget endpoints.
* Preserved WordPress.org review fixes from 6.2.4.

= 6.2.4 =
* Updated WordPress.org documentation and external-service disclosures.
* Added the submitting WordPress.org user to Contributors.
* Removed the unnecessary manual text-domain loading call for WordPress.org-hosted translations.
* Made the frontend loader honor the configured Widget URL.
* Switched the administrative API request to WordPress safe HTTP handling.

= 6.2.3 =
* Previous WordPress.org submission build.
