<?php
/**
 * Plugin Name: LeadyIA Premium
 * Plugin URI: https://leadyia.com/integracoes/wordpress/
 * Description: Connect WordPress and WooCommerce to LeadyIA with visual configuration, secure context, diagnostics, and conversion shortcuts.
 * Version: 6.2.5
 * Author: LeadyIA
 * Author URI: https://leadyia.com/
 * Text Domain: leadyia-premium
 * Domain Path: /languages
 * Requires at least: 6.2
 * Requires PHP: 7.4
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) {
    exit;
}

define('LEADYIA_PREMIUM_VERSION', '6.2.5');
define('LEADYIA_PREMIUM_FILE', __FILE__);
define('LEADYIA_PREMIUM_PATH', plugin_dir_path(__FILE__));
define('LEADYIA_PREMIUM_URL', plugin_dir_url(__FILE__));
define('LEADYIA_PREMIUM_OPTION', 'leadyia_premium_settings');

require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-settings.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-cache.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-api-client.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-woocommerce.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-frontend.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-diagnostics.php';
require_once LEADYIA_PREMIUM_PATH . 'includes/class-leadyia-premium-admin.php';

final class LeadyIA_Premium {
    private static $instance = null;

    public static function instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('plugins_loaded', array($this, 'boot'));
        register_activation_hook(LEADYIA_PREMIUM_FILE, array($this, 'activate'));
    }

    public function boot() {
        LeadyIA_Premium_Settings::instance();
        LeadyIA_Premium_Cache::instance();
        LeadyIA_Premium_Frontend::instance();
        LeadyIA_Premium_Admin::instance();

        $installed_version = (string) get_option('leadyia_premium_version', '');
        if (LEADYIA_PREMIUM_VERSION !== $installed_version) {
            update_option('leadyia_premium_version', LEADYIA_PREMIUM_VERSION, false);
            update_option('leadyia_premium_loader_revision', time(), false);
            LeadyIA_Premium_Cache::instance()->purge_all();
        }
    }

    public function activate() {
        $current = get_option(LEADYIA_PREMIUM_OPTION, array());
        update_option(
            LEADYIA_PREMIUM_OPTION,
            wp_parse_args($current, LeadyIA_Premium_Settings::defaults()),
            false
        );
        update_option('leadyia_premium_version', LEADYIA_PREMIUM_VERSION, false);
        update_option('leadyia_premium_loader_revision', time(), false);
        if (function_exists('rocket_clean_domain')) { rocket_clean_domain(); }
    }
}

LeadyIA_Premium::instance();
