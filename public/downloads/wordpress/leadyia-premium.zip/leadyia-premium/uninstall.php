<?php
if (!defined('WP_UNINSTALL_PLUGIN')) exit;
// Preserve settings by default to make reinstall/upgrade safe.
// Administrators may delete the option manually if permanent removal is required.
