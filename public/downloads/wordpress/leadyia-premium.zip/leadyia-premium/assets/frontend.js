(() => {
  window.__LEADYIA_PREMIUM_FRONTEND_COMPAT__ = true;
})();
