(() => {
  const tabs = [...document.querySelectorAll("[data-tab]")];
  const panels = [...document.querySelectorAll("[data-panel]")];

  tabs.forEach((tab) =>
    tab.addEventListener("click", () => {
      tabs.forEach((item) =>
        item.classList.toggle("is-active", item === tab)
      );
      panels.forEach((panel) =>
        panel.classList.toggle(
          "is-active",
          panel.dataset.panel === tab.dataset.tab
        )
      );
    })
  );

  const button = document.getElementById("leadyia-test-connection");
  const result = document.getElementById("leadyia-test-result");

  if (!button || !result) return;

  button.addEventListener("click", async () => {
    const tenant = document
      .querySelector('input[name="leadyia_premium_settings[tenant_id]"]')
      ?.value?.trim();

    const enabled = document
      .querySelector('input[name="leadyia_premium_settings[enabled]"]')
      ?.checked;

    const playbook = document
      .querySelector('select[name="leadyia_premium_settings[playbook]"]')
      ?.value;

    const widgetUrl = document
      .querySelector('input[name="leadyia_premium_settings[widget_url]"]')
      ?.value?.trim();

    button.disabled = true;
    result.textContent = LeadyIAAdmin.testing;

    try {
      const body = new URLSearchParams({
        action: "leadyia_premium_test_connection",
        nonce: LeadyIAAdmin.nonce,
        tenantId: tenant || "",
        enabled: enabled ? "1" : "",
        playbook: playbook || "",
        widgetUrl: widgetUrl || "",
      });

      const response = await fetch(LeadyIAAdmin.ajaxUrl, {
        method: "POST",
        credentials: "same-origin",
        body,
      });

      const json = await response.json();

      result.textContent =
        json?.data?.message ||
        (json.success
          ? "Conexão confirmada e salva."
          : "Falha na conexão.");

      result.className = json.success ? "is-success" : "is-error";
    } catch (error) {
      result.textContent = "Não foi possível concluir o teste.";
      result.className = "is-error";
    } finally {
      button.disabled = false;
    }
  });
})();
