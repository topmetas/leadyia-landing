(function (blocks, element, components, i18n, blockEditor) {
  const el = element.createElement
  blocks.registerBlockType('leadyia/chat-button', {
    apiVersion: 2,
    title: i18n.__('Botão LeadyIA', 'leadyia-premium'),
    icon: 'format-chat',
    category: 'widgets',
    attributes: { label: { type: 'string', default: i18n.__('Falar com a IA', 'leadyia-premium') } },
    edit: function (props) {
      return el('div', { className: 'leadyia-block-editor' },
        el(components.TextControl, {
          label: i18n.__('Texto do botão', 'leadyia-premium'),
          value: props.attributes.label,
          onChange: function (value) { props.setAttributes({ label: value }) }
        }),
        el(components.Button, { variant: 'primary' }, props.attributes.label)
      )
    },
    save: function () { return null }
  })
})(window.wp.blocks, window.wp.element, window.wp.components, window.wp.i18n, window.wp.blockEditor)
